#ifndef StepperMotor_h
#define StepperMotor_h

#include <Arduino.h>

class StepperMotor {
  public:
    // Конструктор для инициализации пинов
    StepperMotor(int stepPin, int dirPin, int enPin, int delayTime = 2);
    
    // Инициализация пинов
    void begin();
    
    // Операции с шаговым двигателем
    void rotate(int steps);
    void disable();
    void enable();
    
  private:
    int _stepPin;
    int _dirPin;
    int _enPin;
    int _delayTime;
    
    // функция для выполнения шагов
    void step();
};

#endif
