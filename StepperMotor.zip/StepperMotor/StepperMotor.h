#ifndef StepperMotor_h
#define StepperMotor_h

#include <Arduino.h>
#include <AccelStepper.h>

class StepperMotor {
  public:
    // Конструктор для инициализации пинов
    StepperMotor(int stepPin, int dirPin, int enPin);
    
    // Инициализация пинов
    void begin();
    
    // Операции с шаговым двигателем
    void rotate(int steps);
    void disable();
    void enable();
    
    // Установка скорости и ускорения
    void setSpeed(long speed, long accel);

  private:
    int _stepPin;
    int _dirPin;
    int _enPin;
    
    AccelStepper _stepper;
};

#endif
