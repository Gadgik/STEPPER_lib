#include "StepperMotor.h"

StepperMotor::StepperMotor(int stepPin, int dirPin, int enPin, int delayTime) {
  _stepPin = stepPin;
  _dirPin = dirPin;
  _enPin = enPin;
  _delayTime = delayTime;
}

void StepperMotor::begin() {
  pinMode(_stepPin, OUTPUT);
  pinMode(_dirPin, OUTPUT);
  pinMode(_enPin, OUTPUT);
}

void StepperMotor::rotate(int steps) {
  digitalWrite(_dirPin, (steps > 0) ? HIGH : LOW);
  steps = abs(steps);

  enable();
  delay(5);
  
  for (int i = 0; i < steps; i++) {
    step();
  }

  delay(5);
  disable();
}

void StepperMotor::enable() {
    digitalWrite(_enPin, LOW);  // LOW = включено
}

void StepperMotor::disable() {
    digitalWrite(_enPin, HIGH); // HIGH = отключено
}
void StepperMotor::step() {
  digitalWrite(_stepPin, HIGH);
  delay(_delayTime);
  digitalWrite(_stepPin, LOW);
  delay(_delayTime);
}
