#include "StepperMotor.h"
#include <AccelStepper.h>

StepperMotor::StepperMotor(int stepPin, int dirPin, int enPin)
    : _stepPin(stepPin), _dirPin(dirPin), _enPin(enPin), _stepper(AccelStepper::DRIVER, stepPin, dirPin) {}

void StepperMotor::begin() {
  pinMode(_stepPin, OUTPUT);
  pinMode(_dirPin, OUTPUT);
  pinMode(_enPin, OUTPUT);

  digitalWrite(_enPin, HIGH);  // Выключаем мотор по умолчанию
}

void StepperMotor::setSpeed(long speed, long accel) {
  _stepper.setMaxSpeed(speed);
  _stepper.setAcceleration(accel);
}

void StepperMotor::rotate(int steps) {
  enable();  // Включаем мотор
  _stepper.move(steps);
  while(_stepper.distanceToGo() != 0) {
    _stepper.run();  // Постепенное движение к цели
  }
  disable();  // Выключаем мотор
}

void StepperMotor::enable() {
  digitalWrite(_enPin, LOW);  // Включаем мотор
}

void StepperMotor::disable() {
  digitalWrite(_enPin, HIGH);  // Выключаем мотор
}
